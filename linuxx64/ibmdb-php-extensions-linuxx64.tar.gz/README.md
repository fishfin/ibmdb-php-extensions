**Pre-compiled IBM DB2 Extensions for Linux 64-bit**
----------
    Only thread-safe versions are made available.


PHP 5.6 = 20131226
PHP 7.0 = 20151012
PHP 7.1 = 20160303