**Pre-compiled IBM DB2 Extensions for Windows 32-bit**
----------
    * Both thread-safe and non-thread-safe versions are made available.
    * Thread and Non-thread-safe versions for IBM_DB2 for PHP v5.6 are missing, sorry!


PHP 5.6 = 20131226
PHP 7.0 = 20151012
PHP 7.1 = 20160303